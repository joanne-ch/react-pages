
import React, {useState} from "react";
import "./App.css";
import ReactDOM from "react-dom";

function App() 

{
  return (
    <div className = "wrapper">
      <Card 
      img ="https://st.depositphotos.com/2704315/3185/v/950/depositphotos_31854241-stock-illustration-vector-user-profile-avatar-woman.jpg"
      title="Katherine Wright"
      desc="Nanny needed! @5.30pm" />
      <Card 
      img  = "https://www.activacionciudadana.org/img/team-2.png"
      title="Maria Johnson"
      desc="Pick up the kids from school!" />
      <Card 
      img ="https://st2.depositphotos.com/1537427/5859/v/950/depositphotos_58597527-stock-illustration-female-user-icon.jpg"
      title="Joanne Brown"
      desc="whole day babysitter" />
    
      
    </div>
  )
}
function Card(props){
  const [label, setLabel] = useState("Accept")

  function sayHello()
{
  setLabel("Accepted") 
  alert('Accepted!');
}

  return(
    <div className="card">
      <div className="card__body">
      
        <img src= {props.img} class ="card__image"/>
        <h2 className="card__title">{props.title}</h2>
        <p className = "card__description">{props.desc}</p>

      </div>
      <button onClick={sayHello}className = "card__btn">
      {label}
    </button>
           
                  
    </div>
    
  )
}

export default App;

